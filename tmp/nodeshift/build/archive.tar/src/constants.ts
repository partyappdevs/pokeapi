export const jwtConstants = {
  secret: 'Se4tg2Djs9028fsjz$%12sA',
};
